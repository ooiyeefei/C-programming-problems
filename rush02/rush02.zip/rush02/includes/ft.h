/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yooi <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 19:21:25 by yooi              #+#    #+#             */
/*   Updated: 2016/08/28 20:11:18 by yooi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>

# define NUM(x) (x>='0' && x<='9')
# define MAX_BUF 100000

void				ft_putchar(char c);
void				ft_putstr(char *str);
void				ft_putnbr(int nb);
int					ft_strcmp(char *s1, char *s2);
void				gen_result(char *rush_tag, int x, int y);
void				rush00(int x, int y, char *str);
void				rush01(int x, int y, char *str);
void				rush02(int x, int y, char *str);
void				rush03(int x, int y, char *str);
void				rush04(int x, int y, char *str);
char				*ft_strcat(char *s1, char *s2);
void				last_value(char *str, int *k, int *j);
void				increment(int *i, int *k);
void				init_value(int *k, int *j);
void				rushcmp(char *input, char *rush, int *dim, char *rush_tag);
void				read_input(char *input, int *x, int *y);

#endif
